import React, { useState, useEffect } from "react";

const RickAndMortyCharacters = () => {
  const [characters, setCharacters] = useState([]);
  const [search, setSearch] = useState("");
  const [species, setSpecies] = useState("");
  const [gender, setGender] = useState("");

  const fetchCharacters = async () => {
    let url = `https://rickandmortyapi.com/api/character/?`;

    if (search) url += `name=${search}&`;
    if (species) url += `species=${species}&`;
    if (gender) url += `gender=${gender}&`;

    try {
      const response = await fetch(url);
      const data = await response.json();
      setCharacters(data.results || []);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    fetchCharacters();
  }, []);

  const handleSearch = (e) => {
    if (e.key === "Enter") {
      fetchCharacters();
    }
  };

  return (
    <div>
      {/* Filters */}
      <div className="filters">
        <input
          type="text"
          placeholder="Search by name..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          onKeyDown={handleSearch}
        />
        <select value={species} onChange={(e) => setSpecies(e.target.value)}>
          <option value="">All Species</option>
          <option value="Human">Human</option>
          <option value="Humanoid">Humanoid</option>
          <option value="Cronenberg">Cronenberg</option>
        </select>
        <select value={gender} onChange={(e) => setGender(e.target.value)}>
          <option value="">All Genders</option>
          <option value="male">Male</option>
          <option value="female">Female</option>
          <option value="genderless">Genderless</option>
          <option value="unknown">Unknown</option>
        </select>
        <button onClick={fetchCharacters}>Apply</button>
      </div>

      {/* Characters Grid */}
      <div className="container">
        {characters.map((char) => (
          <div key={char.id} className="card">
            <img src={char.image} alt={char.name} />
            <div className="card-details">
              <h3>{char.name}</h3>
              <p><b>Gender:</b> {char.gender}</p>
              <p><b>Species:</b> {char.species}</p>
              <p><b>Location:</b> {char.location.name}</p>
              <p><b>First Seen In:</b> {char.episode[0]}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RickAndMortyCharacters;
