import React from 'react'
import RickAndMortyCharacters from "./components/RickAndMortyCharacters.jsx";

function App() {
  return (
    <div>
      <h1 style={{ textAlign: "center", marginTop: "20px" }}>Rick and Morty Characters</h1>
      <RickAndMortyCharacters />
    </div>
  )
}

export default App

